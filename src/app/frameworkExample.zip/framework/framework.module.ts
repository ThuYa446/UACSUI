import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import {MenubarComponent} from '../Framework/menubar.component';
import {FrameworkRoutingModule} from '../Framework/framework-routing.module';

import {IntercomService} from '../Services/intercom.service';

@NgModule({
  declarations: [
    MenubarComponent
  ],
  imports: [
     BrowserModule,
     FrameworkRoutingModule,
     FormsModule,
  ],
  exports: [
    MenubarComponent
  ],
  providers: [
    IntercomService,
  ],
  bootstrap: [
     MenubarComponent
  ]
})
export class FrameworkModule { }
