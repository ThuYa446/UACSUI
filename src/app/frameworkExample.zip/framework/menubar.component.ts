import { Component, OnInit, enableProdMode } from '@angular/core';

enableProdMode();
@Component({
  // tslint:disable-next-line: component-selector
  selector: 'menu-bar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})

export class MenubarComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {

  }
}
